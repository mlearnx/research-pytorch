 PyTorch for former Torch users
 ------------------------------
 
1. tensor_tutorial.py
	Tensors
	http://pytorch.org/tutorials/beginner/former_torchies/tensor_tutorial.html

2. autograd.py
	Autograd
	http://pytorch.org/tutorials/beginner/former_torchies/autograd_tutorial.html

3. nn_tutorial.py
	nn package
	http://pytorch.org/tutorials/beginner/former_torchies/nn_tutorial.html

4. parallelism_tutorial.py
	Multi-GPU examples
	http://pytorch.org/tutorials/beginner/former_torchies/parallelism_tutorial.html
